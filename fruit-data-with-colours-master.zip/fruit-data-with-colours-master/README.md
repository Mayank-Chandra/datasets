# fruit-data-with-colours
Solving classification problem with Python using the fruit data with colours
The fruits dataset was created by Dr. Iain Murray from University of Edinburgh. 
He bought a few dozen oranges, lemons and apples of different varieties, and recorded their measurements in a table. 
And then the professors at University of Michigan formatted the fruits data slightly.
The Python library and the dataset is open for learning purposes
